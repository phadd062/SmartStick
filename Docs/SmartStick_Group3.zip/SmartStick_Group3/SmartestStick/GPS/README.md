# Google-Maps-Android
# Reference - 
https://developers.google.com/maps/documentation/android-api/start
# Google map version 2 API demo.
# Showing multiple location on map usig bounds.

Steps to develope demo - 
#Step 1. Download Android Studio
#Step 2. Install the Google Play services SDK
#Step 3. Create a Google Maps project
#Step 4. Get a Google Maps API key
#Step 5. Hello Map! Take a look at the code

# API key get steps-

![api_key](https://user-images.githubusercontent.com/28217318/35284206-37535434-0080-11e8-9a2b-600b0c5ed50b.PNG)

![api_key2](https://user-images.githubusercontent.com/28217318/35284218-3af40b7e-0080-11e8-8712-b89e948b934d.PNG)

![api_key3](https://user-images.githubusercontent.com/28217318/35284224-3e9fcdee-0080-11e8-9211-a060556c77b2.PNG)


# App screen shot - 
![device-2018-01-23-204324](https://user-images.githubusercontent.com/28217318/35283844-4a2fd07e-007f-11e8-82ae-aeceaeb84aaa.png)





